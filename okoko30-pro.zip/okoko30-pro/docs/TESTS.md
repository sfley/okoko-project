# Rapport de validation — OKOKO 3.0 Pro

Validation exécutée le 22 octobre 2026 dans l’environnement cloud Linux amd64. Go 1.27.3, Node.js 24.19.0, npm 11.9.0, Chromium 154.0.8037.57, Playwright 1.56.1.

## Résultats réellement exécutés

| Contrôle | Résultat et portée |
|---|---|
| Sources originales de `okoko20.zip` : `go test ./...` | 9 tests existants réussis avant refonte |
| Backend courant : `go test -count=1 ./...` | 15 tests réussis, aucun échec ni saut |
| Backend courant : `go test -race -count=1 ./...` | Réussi, aucune course détectée par le détecteur |
| Backend courant : `go vet ./...` | Réussi |
| Modules Go : `go mod verify` | Tous les modules vérifiés ; `go.mod` et `go.sum` identiques à l’archive |
| Frontend : `npm ci` puis `npm run build` | Réussi avec le verrou ; reconstruction répétée sans modification du verrou |
| Données météo : `npm test` | 4 tests réussis : absences, dates/heures invalides, prévision quotidienne sans horaire inventé, minuit |
| Navigateur : `OKOKO_REAL_BACKEND=1 npm run test:browser` | 9 scénarios réussis, 0 échec, 0 saut |
| Linux ARM64 : `CGO_ENABLED=0 GOOS=linux GOARCH=arm64 go build ...` | Binaire principal et outil d’import compilés ; type ELF aarch64 statique vérifié |
| Linux amd64 : binaire principal | Démarré et utilisé pour les tests HTTP et navigateur |
| `/health`, `/api/v3/snapshot`, `/api/v3/system` | HTTP 200 ; valeurs absentes conservées comme NULL ; délais locaux dans `http-checks.json` |
| Frontend statique servi par Go | Chargement réussi ; version gzip du JS effectivement renvoyée et décompressée |
| Scripts cloud | Installation complète exécutée ; démarrage, deuxième démarrage sans doublon, arrêt et redémarrage vérifiés |
| Script de déploiement distant | Syntaxe shell contrôlée avec `sh -n` ; aucun déploiement réseau exécuté |
| Dépendances npm de production | Audit : aucune vulnérabilité signalée lors du contrôle ; ce résultat ne couvre pas un audit général du code |
| Identifiant de connexion fourni dans l’archive d’origine | Aucun exemplaire dans les sources livrées ; configurations d’exemple nettoyées |

Le téléchargement Go standard était initialement bloqué lors de sa redirection vers le stockage de modules. Les sources des versions exactes ont été récupérées dans leurs dépôts officiels indiqués par les métadonnées Go, puis vérifiées contre les sommes de `go.sum` inchangé. Aucune vérification TLS ou de somme de contrôle n’a été désactivée. Les dépendances sont maintenant disponibles dans le cache local.

## Navigateur et inspection visuelle

Les six pages ont été ouvertes, capturées et inspectées visuellement sur ordinateur et mobile. Un contrôle tablette a été ajouté et sa disposition corrigée après inspection. Les captures sous `captures/` couvrent : tableau de bord, chauffage, analyse, pellets, météo et système, aux tailles 1440 × 1050, 1024 × 900 et 390 × 844. Elles utilisent exclusivement des données simulées identifiées par un bandeau. Elles ne constituent pas une validation des mesures de votre chaudière.

Les scénarios testent :

- navigation sur les six pages sans erreur JavaScript ni débordement horizontal de la page ; alignement des modules sur tablette ;
- déplacement par glisser-déposer, redimensionnement par poignée, changement de taille, ajout et retrait de widgets ;
- conservation des modules et de leurs positions après rechargement ;
- absence de fausse valeur zéro ou de prévision inventée lorsque les données manquent ;
- affichage de la consigne programmée, sans substitution par la consigne technique de 8 °C ;
- contrôle de période et masquage d’une série par sa légende ;
- envoi du formulaire de recharge ;
- application réellement servie par Go, toutes les routes principales accessibles, NAS non configuré et télémétrie absente.

La dernière vérification HTTP non simulée utilise une base locale temporaire de développement. Les tests Go vérifient aussi l’addition et le refus de doublon d’une recharge, le contenu WAL de la sauvegarde, l’import CSV et sa déduplication, les valeurs NULL, la fraîcheur du cache, l’absence de requête chaudière provoquée par huit lectures de l’API, la conservation des corrections et recharges au redémarrage et le masquage des accès privés dans les erreurs d’import.

## Corrections et conservation

- Disposition responsive explicite pour éviter les vides excessifs sur tablette.
- Adaptation des widgets compacts pour garder leurs informations essentielles lisibles.
- Dates météo invalides laissées non affectées ; température vide laissée inconnue.
- Les erreurs des accès `/all` et `/logN` masquent le préfixe privé de connexion.
- L’initialisation des archives ne remplace plus une consommation mensuelle déjà enregistrée.
- Les 7 fonctions de calcul et d’import listées dans `source-preservation.json` sont identiques après `gofmt`, dont les deux fonctions de calcul des pellets. Aucun changement de formule n’a été effectué.

## Limites restantes

- Aucun accès à votre chaudière réelle, NAS réel ou base SQLite de production ; leur compatibilité finale doit être contrôlée après déploiement et sauvegarde.
- Les binaires ARM64 ont été compilés, pas exécutés sur votre routeur. La consommation mémoire et les performances sur OpenWrt ne sont pas mesurées ici.
- Les scripts PowerShell/Windows ont été écrits et relus, mais pas exécutés sous Windows ; le déploiement SSH et la restauration distante ne sont pas testés sur votre matériel.
- Le cockpit est conservé dans le navigateur, sans synchronisation entre appareils. Aucun test sur écran tactile physique ou navigateur Safari n’a été exécuté.
- Le chauffage reste une supervision en lecture seule. Aucune API de commande ÖkoFEN non documentée n’a été ajoutée.
- Les prévisions dépendent du format et des champs réellement transmis. Les formats de date inconnus restent visibles sans affectation arbitraire ; pas de météo horaire fabriquée.
- Un montage NFS bloqué au niveau du système peut suspendre le travailleur d’import. Le cache temps réel et la navigation ne lisent pas le NAS ; les API d’historique ont des délais bornés. Un tel blocage matériel n’a pas été reproduit.
- Aucune sauvegarde périodique nouvelle n’est annoncée : la sauvegarde est déclenchée à la demande.
- Le brouillon cloud contient `install_script`, `start_skill` et le domaine nécessaire au téléchargement Go. Sa sauvegarde n’est pas une publication ; une restauration dans une nouvelle tâche n’a pas été testée.
